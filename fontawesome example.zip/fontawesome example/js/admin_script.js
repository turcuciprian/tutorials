jQuery(document).ready(function ($) {
    var menu_item_object;
    $('.thickbox').click(function(){
       menu_item_object = $(this);
       console.log(menu_item_object);
       //console.log(menu_item_object);
    });
    $('.icon-button').click(function () {
        var selected_icon = $(this).children('i').attr('id');
        menu_item_object.parents('div').children('.faIMG').children('i').removeClass('').addClass('fa fa-2x '+selected_icon);
        menu_item_object.parents('div').children('input[type="hidden"].edit-menu-item-cIcon').val(selected_icon);//save the main value item
        tb_remove();
    });
});